from pathlib import Path
from typing import List

from lxml import etree

from app.models.normalized_firewall_model import (
    AddressGroup,
    AddressObject,
    FirewallConfig,
    Scope,
    ScopeType,
    SecurityRule,
    Vendor,
)
from app.parsers.base import BaseParser


class PaloAltoParser(BaseParser):
    def __init__(self, file_path: str):
        self.file_path = Path(file_path)
        self.tree = None
        self.root = None

    def load(self) -> None:
        raw_text = self.file_path.read_text(encoding="utf-8", errors="ignore")

        replacements = {
            "&QT;": '"',
            "&APOS;": "'",
        }

        for bad, good in replacements.items():
            raw_text = raw_text.replace(bad, good)

        parser = etree.XMLParser(recover=True, huge_tree=True)
        self.root = etree.fromstring(raw_text.encode("utf-8"), parser=parser)
        self.tree = etree.ElementTree(self.root)

    def parse(self) -> FirewallConfig:
        if self.root is None:
            self.load()

        if self._is_panorama():
            return self._parse_panorama()
        return self._parse_standalone()

    def _is_panorama(self) -> bool:
        return self.root.find(".//devices/entry/device-group") is not None

    def _parse_standalone(self) -> FirewallConfig:
        config = FirewallConfig(
            vendor=Vendor.PALO_ALTO,
            source_file=str(self.file_path),
            config_type="standalone",
        )

        hostname = self.root.findtext(".//devices/entry/deviceconfig/system/hostname")
        config.hostname = hostname

        vsys_entries = self.root.findall(".//devices/entry/vsys/entry")
        if not vsys_entries:
            vsys_entries = [None]

        for vsys in vsys_entries:
            vsys_name = vsys.get("name") if vsys is not None else "default"
            scope = Scope(name=vsys_name, scope_type=ScopeType.STANDALONE)

            zone_entries = self.root.findall(".//devices/entry/network/zone/entry")
            scope.zones = self._extract_names(zone_entries)

            addr_entries = self.root.findall(".//devices/entry/vsys/entry/address/entry")
            scope.address_objects = [self._parse_address_object(entry) for entry in addr_entries]

            addr_group_entries = self.root.findall(".//devices/entry/vsys/entry/address-group/entry")
            scope.address_groups = [self._parse_address_group(entry) for entry in addr_group_entries]

            svc_entries = self.root.findall(".//devices/entry/vsys/entry/service/entry")
            scope.service_objects = self._extract_names(svc_entries)

            svc_group_entries = self.root.findall(".//devices/entry/vsys/entry/service-group/entry")
            scope.service_groups = self._extract_names(svc_group_entries)

            app_group_entries = self.root.findall(".//devices/entry/vsys/entry/application-group/entry")
            scope.application_groups = self._extract_names(app_group_entries)

            sec_rule_entries = self.root.findall(".//devices/entry/vsys/entry/rulebase/security/rules/entry")
            scope.security_rules = [self._parse_security_rule(rule) for rule in sec_rule_entries]

            nat_rule_entries = self.root.findall(".//devices/entry/vsys/entry/rulebase/nat/rules/entry")
            scope.nat_rules = self._extract_names(nat_rule_entries)

            config.scopes.append(scope)

        return config

    def _parse_panorama(self) -> FirewallConfig:
        config = FirewallConfig(
            vendor=Vendor.PALO_ALTO,
            source_file=str(self.file_path),
            config_type="panorama",
        )

        hostname = self.root.findtext(".//devices/entry/deviceconfig/system/hostname")
        config.hostname = hostname

        shared_scope = Scope(name="shared", scope_type=ScopeType.SHARED)
        shared_scope.address_objects = [
            self._parse_address_object(entry)
            for entry in self.root.findall(".//shared/address/entry")
        ]
        shared_scope.address_groups = [
            self._parse_address_group(entry)
            for entry in self.root.findall(".//shared/address-group/entry")
        ]
        shared_scope.service_objects = self._extract_names(
            self.root.findall(".//shared/service/entry")
        )
        shared_scope.service_groups = self._extract_names(
            self.root.findall(".//shared/service-group/entry")
        )
        shared_scope.application_groups = self._extract_names(
            self.root.findall(".//shared/application-group/entry")
        )

        shared_pre_rules = self.root.findall(".//shared/pre-rulebase/security/rules/entry")
        shared_post_rules = self.root.findall(".//shared/post-rulebase/security/rules/entry")
        shared_scope.security_rules = [self._parse_security_rule(rule) for rule in (shared_pre_rules + shared_post_rules)]

        shared_scope.nat_rules = self._extract_names(
            self.root.findall(".//shared/pre-rulebase/nat/rules/entry")
        ) + self._extract_names(
            self.root.findall(".//shared/post-rulebase/nat/rules/entry")
        )

        if any(shared_scope.summary().values()):
            config.scopes.append(shared_scope)

        dg_entries = self.root.findall(".//devices/entry/device-group/entry")
        for dg in dg_entries:
            dg_name = dg.get("name")
            scope = Scope(name=dg_name, scope_type=ScopeType.DEVICE_GROUP)

            scope.address_objects = [self._parse_address_object(entry) for entry in dg.findall("./address/entry")]
            scope.address_groups = [self._parse_address_group(entry) for entry in dg.findall("./address-group/entry")]
            scope.service_objects = self._extract_names(dg.findall("./service/entry"))
            scope.service_groups = self._extract_names(dg.findall("./service-group/entry"))
            scope.application_groups = self._extract_names(dg.findall("./application-group/entry"))

            dg_pre_rules = dg.findall("./pre-rulebase/security/rules/entry")
            dg_post_rules = dg.findall("./post-rulebase/security/rules/entry")
            scope.security_rules = [self._parse_security_rule(rule) for rule in (dg_pre_rules + dg_post_rules)]

            scope.nat_rules = (
                self._extract_names(dg.findall("./pre-rulebase/nat/rules/entry")) +
                self._extract_names(dg.findall("./post-rulebase/nat/rules/entry"))
            )

            config.scopes.append(scope)

        template_entries = self.root.findall(".//devices/entry/template/entry")
        for template in template_entries:
            template_name = template.get("name")
            scope = Scope(name=template_name, scope_type=ScopeType.TEMPLATE)
            scope.zones = self._extract_names(
                template.findall(".//config/devices/entry/network/zone/entry")
            )
            config.scopes.append(scope)

        return config

    def _parse_address_object(self, entry: etree._Element) -> AddressObject:
        value = (
            entry.findtext("./ip-netmask")
            or entry.findtext("./ip-range")
            or entry.findtext("./fqdn")
            or entry.findtext("./ip-wildcard")
        )

        return AddressObject(
            name=entry.get("name", "unnamed-address-object"),
            value=value,
            description=entry.findtext("./description"),
            raw={"xml_tag": entry.tag},
        )

    def _parse_address_group(self, entry: etree._Element) -> AddressGroup:
        members = [m.text for m in entry.findall("./static/member") if m.text]
        return AddressGroup(
            name=entry.get("name", "unnamed-address-group"),
            members=members,
            description=entry.findtext("./description"),
            raw={"xml_tag": entry.tag},
        )

    def _parse_security_rule(self, rule_entry: etree._Element) -> SecurityRule:
        profile_group = rule_entry.findtext("./profile-setting/group/member")

        return SecurityRule(
            name=rule_entry.get("name", "unnamed-rule"),
            from_zones=self._member_values(rule_entry.findall("./from/member")),
            to_zones=self._member_values(rule_entry.findall("./to/member")),
            source_addresses=self._member_values(rule_entry.findall("./source/member")),
            source_users=self._member_values(rule_entry.findall("./source-user/member")),
            destination_addresses=self._member_values(rule_entry.findall("./destination/member")),
            applications=self._member_values(rule_entry.findall("./application/member")),
            services=self._member_values(rule_entry.findall("./service/member")),
            categories=self._member_values(rule_entry.findall("./category/member")),
            action=rule_entry.findtext("./action", default="allow"),
            disabled=self._to_bool(rule_entry.findtext("./disabled", default="no")),
            description=rule_entry.findtext("./description"),
            log_start=self._to_bool(rule_entry.findtext("./log-start", default="no")),
            log_end=self._to_bool(rule_entry.findtext("./log-end", default="no")),
            log_setting=rule_entry.findtext("./log-setting"),
            profile_group=profile_group,
            profile_antivirus=rule_entry.findtext("./profile-setting/profiles/virus/member"),
            profile_antispyware=rule_entry.findtext("./profile-setting/profiles/spyware/member"),
            profile_vulnerability=rule_entry.findtext("./profile-setting/profiles/vulnerability/member"),
            profile_url_filtering=rule_entry.findtext("./profile-setting/profiles/url-filtering/member"),
            profile_file_blocking=rule_entry.findtext("./profile-setting/profiles/file-blocking/member"),
            profile_wildfire_analysis=rule_entry.findtext("./profile-setting/profiles/wildfire-analysis/member"),
            raw={"xml_tag": rule_entry.tag},
        )

    @staticmethod
    def _extract_names(entries: List[etree._Element]) -> List[str]:
        return [entry.get("name") for entry in entries if entry.get("name")]

    @staticmethod
    def _member_values(entries: List[etree._Element]) -> List[str]:
        return [entry.text for entry in entries if entry.text]

    @staticmethod
    def _to_bool(value: str) -> bool:
        return str(value).strip().lower() in {"yes", "true", "1"}