import sys
from pathlib import Path

from app.analysis.exposure_engine import ExposureEngine
from app.analysis.security_analyzer import SecurityAnalyzer
from app.collectors.registry import CollectorRegistry
from app.parsers.parser_dispatcher import ParserDispatcher
from app.reports.report_exporter import ReportExporter
from app.simulation.policy_simulator import PolicySimulator


def analyze_config_file(file_path: str, customer_name: str = "Demo Customer") -> None:
    dispatcher = ParserDispatcher()

    try:
        detection, config = dispatcher.parse(file_path)
    except ValueError as exc:
        print("Detected config:")
        print({"vendor": "unknown", "config_type": "unknown", "parser": "unknown"})
        print(str(exc))
        return

    print("Detected config:")
    print(detection)

    analyzer = SecurityAnalyzer()
    findings = analyzer.analyze(config)

    print("NISE parser executed successfully.")
    print(config.summary())
    print(f"\nTotal findings: {len(findings)}")

    for finding in findings[:20]:
        print(
            f"[{finding.severity.value.upper()}] "
            f"{finding.finding_code.value} | "
            f"Scope={finding.scope_name} | "
            f"Rule={finding.rule_name} | "
            f"{finding.issue}"
        )

    reports_dir = Path("output")
    exporter = ReportExporter()

    csv_path = reports_dir / "findings.csv"
    pdf_path = reports_dir / "executive_report.pdf"

    exporter.export_findings_csv(findings, str(csv_path))
    summary = exporter.build_executive_summary(findings)
    exporter.export_executive_pdf(summary, str(pdf_path), customer_name=customer_name)

    print(f"\nCSV report written to: {csv_path}")
    print(f"PDF report written to: {pdf_path}")
    print(f"Executive summary: {summary}")


def run_file_analysis(file_path: str) -> None:
    analyze_config_file(file_path=file_path, customer_name="Demo Customer")


def run_collector(host: str, api_key: str) -> None:
    registry = CollectorRegistry()
    collector_class = registry.get_collector_class("palo_alto_api")

    if collector_class is None:
        print("No collector found.")
        return

    collector = collector_class(host=host, api_key=api_key)
    result = collector.collect()

    print("Collector result:")
    print(result)

    if result.get("status") != "success":
        print("Collection did not succeed, so analysis will not continue.")
        return

    running_config_file = result.get("running_config_file")
    if not running_config_file:
        print("No running config file returned from collector.")
        return

    print("\nStarting analysis of collected configuration...\n")
    analyze_config_file(file_path=running_config_file, customer_name=host)


def run_simulation(
    file_path: str,
    scope_name: str,
    source: str,
    destination: str,
    application: str,
    service: str,
) -> None:
    dispatcher = ParserDispatcher()
    _, config = dispatcher.parse(file_path)

    simulator = PolicySimulator()
    result = simulator.simulate(
        config=config,
        scope_name=scope_name,
        source=source,
        destination=destination,
        application=application,
        service=service,
    )

    print("Simulation result:")
    print(result)


def run_blast_radius(file_path: str, scope_name: str, start_zone: str) -> None:
    dispatcher = ParserDispatcher()
    _, config = dispatcher.parse(file_path)

    engine = ExposureEngine()
    result = engine.analyze_blast_radius(
        config=config,
        scope_name=scope_name,
        start_zone=start_zone,
    )

    print("Blast radius analysis:")
    print(result)


def main() -> None:
    if len(sys.argv) < 3:
        print("Usage:")
        print("  python main.py file <path_to_config>")
        print("  python main.py collect <host> <api_key>")
        print("  python main.py simulate <path_to_config> <scope> <source> <destination> <application> <service>")
        print("  python main.py blast-radius <path_to_config> <scope> <start_zone>")
        return

    mode = sys.argv[1]

    if mode == "file":
        run_file_analysis(sys.argv[2])

    elif mode == "collect":
        if len(sys.argv) < 4:
            print("Usage: python main.py collect <host> <api_key>")
            return
        run_collector(sys.argv[2], sys.argv[3])

    elif mode == "simulate":
        if len(sys.argv) < 8:
            print("Usage: python main.py simulate <path_to_config> <scope> <source> <destination> <application> <service>")
            return
        run_simulation(
            file_path=sys.argv[2],
            scope_name=sys.argv[3],
            source=sys.argv[4],
            destination=sys.argv[5],
            application=sys.argv[6],
            service=sys.argv[7],
        )

    elif mode == "blast-radius":
        if len(sys.argv) < 5:
            print("Usage: python main.py blast-radius <path_to_config> <scope> <start_zone>")
            return
        run_blast_radius(
            file_path=sys.argv[2],
            scope_name=sys.argv[3],
            start_zone=sys.argv[4],
        )

    else:
        print(f"Unknown mode: {mode}")
        print("Use 'file', 'collect', 'simulate', or 'blast-radius'.")


if __name__ == "__main__":
    main()