from collections import deque
from typing import Dict, List, Set

from app.models.normalized_firewall_model import FirewallConfig, Scope


class ExposureEngine:
    """
    Attack Path Engine (APE) v1
    Determines what zones are reachable from a starting zone
    based on firewall rules.
    """

    def analyze_blast_radius(
        self,
        config: FirewallConfig,
        scope_name: str,
        start_zone: str,
    ) -> Dict:

        scope = self._find_scope(config, scope_name)

        if scope is None:
            return {"error": f"Scope {scope_name} not found"}

        graph = self._build_zone_graph(scope)

        reachable = self._bfs(graph, start_zone)

        return {
            "start_zone": start_zone,
            "reachable_zones": list(reachable),
            "zone_graph": graph,
        }

    def _find_scope(self, config: FirewallConfig, scope_name: str) -> Scope:
        for scope in config.scopes:
            if scope.name == scope_name:
                return scope
        return None

    def _build_zone_graph(self, scope: Scope) -> Dict[str, Set[str]]:
        graph: Dict[str, Set[str]] = {}

        for rule in scope.security_rules:

            if rule.action != "allow":
                continue

            for src_zone in rule.from_zones:
                for dst_zone in rule.to_zones:

                    if src_zone not in graph:
                        graph[src_zone] = set()

                    graph[src_zone].add(dst_zone)

        return graph

    def _bfs(self, graph: Dict[str, Set[str]], start_zone: str) -> Set[str]:

        visited: Set[str] = set()
        queue = deque([start_zone])

        while queue:

            zone = queue.popleft()

            if zone in visited:
                continue

            visited.add(zone)

            for neighbor in graph.get(zone, []):
                if neighbor not in visited:
                    queue.append(neighbor)

        visited.remove(start_zone)

        return visited